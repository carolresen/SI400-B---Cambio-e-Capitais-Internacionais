/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafico;

/**
 *
 * @author Caroline
 */

import java.awt.Dimension;
import java.io.IOException;
import java.net.MalformedURLException;
import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

// Criação do gráfico do projeto por Caroline 165921 PARA 4 MESES

public class BarsGraphic2 extends JFrame{

public BarsGraphic2(String title) {
super(title);
CategoryDataset dataset = BarsGraphic2.createDataset();
JFreeChart chart = BarsGraphic2.createBarChart(dataset);
ChartPanel panel = new ChartPanel(chart);
panel.setPreferredSize(new Dimension(600, 500));
setContentPane(panel);
}

public static CategoryDataset createDataset() {
DefaultCategoryDataset dataset = new DefaultCategoryDataset();
//Valor aleatórios para testes
dataset.addValue(media(3.22923,3.24743,3.28983,3.2363,3.33823,3.29623,3.0253,27443,3.2893,3.2305), "Venda", "Outubro");
    dataset.addValue(media(3.26283,3.27953,3.25063,3.25793,3.28483,3.28133,3.27843,3.28143,3.27343,3.23843,3.2656), "Compra", "Outubro");
    
    dataset.addValue(media(3.5983,3.61833,3.64413,3.68093,3.69313,63743,3.64733,3.62513,3.65383,3.5878), "Compra", "Setembro");
    dataset.addValue(media(3.63123,3.61633,3.64873,3.64573,3.6553,3.58193,3.5293,3.51773,3.49843,3.49513,3.5014), "Venda", "Setembro");
return dataset; 
}

public static JFreeChart createBarChart(CategoryDataset dataset) {
JFreeChart chart = ChartFactory.createBarChart(
"Dólar", //Titulo
"Meses", // Eixo X
"Cotação Média", //Eixo Y
dataset, // Dados para o grafico
PlotOrientation.VERTICAL, //Orientacao do grafico
true, false, false); // exibir: legendas, tooltips, url
return chart;
}

public static void main( String[] args ) {
BarsGraphic2 chart = new BarsGraphic2("Teste Cotação");
chart.pack();
chart.setVisible(true);
}

public static double media(double... x){
    double media=0;

    for(double valor: x){
        media +=valor;
    }

    return media/x.length;
}
}