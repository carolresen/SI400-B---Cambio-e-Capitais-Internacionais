/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casacambio;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Victória
 */
public class Moeda implements Serializable{

    private String data;
    private String tipo;
    private double valorCompra;
    private double valorVenda;

    
    public String getTipo()
    {
        return this.tipo;
    }
    public void setTipo(String tipo)
    {
        this.tipo = tipo;
    }
    
    public String getData()
    {
        return this.data;
    }
    
    public void setData(String data)
    {
       this.data = data;
    }
    
    public double getCompra()
    {
        return this.valorCompra;
    }
    public void setCompra(double valorCompra)
    {
        this.valorCompra = valorCompra;
    }
    
    public double getVenda()
    {
        return this.valorVenda;
    }
    public void setVenda(double valorVenda)
    {
        this.valorVenda = valorVenda;
    }
    
    //Operacoes matematicas ... Caroline Resende
    
    // SOBRECARGA de METODOS
    public float mediaCompra (float x1, float x2) {
        return (x1+x2)/2;
    }
    
    public float mediaVenda (float x1, float x2) {
        return (x1+x2)/2;
    }
    
    public float mediaCompra (float x1, float x2, float x3) {
        return (x1+x2+x3)/3;
    }
    
    public float mediaVenda (float x1, float x2, float x3) {
        return (x1+x2+x3)/3;
    }
    
    public Moeda(String data, String tipo, double compra, double venda ) {
        this.data = data;
        this.tipo = tipo;
        this.valorCompra = compra;
        this.valorVenda = venda;
    }
    
    public Moeda() {
        // Vazio
    }
        
}