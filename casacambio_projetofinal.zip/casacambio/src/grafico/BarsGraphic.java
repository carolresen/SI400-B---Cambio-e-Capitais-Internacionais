/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafico;
import casacambio.*;

/**
 *
 * @author Caroline
 */

import java.awt.Dimension;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

// Criação do gráfico do projeto por Caroline 165921 PARA 2 MESES

public class BarsGraphic extends JFrame{

public BarsGraphic(String title) {
    super(title);
    CategoryDataset dataset = BarsGraphic.createDataset();
    JFreeChart chart = BarsGraphic.createBarChart(dataset);
    ChartPanel panel = new ChartPanel(chart);
    panel.setPreferredSize(new Dimension(500, 400));
    setContentPane(panel);
}


public static CategoryDataset createDataset() {
    DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    
    Cotacoes cotacoes = new Cotacoes();
    
     LinkedHashMap<String,Double> map = cotacoes.getList();
             
     URL url;
     try {
                url = new URL("http://michael.eti.br/java/DOLAR.csv");
                cotacoes.lerCotacao(url);
                                                          
               
            } catch (MalformedURLException ex) {
                Logger.getLogger(TelaInicial.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(TelaInicial.class.getName()).log(Level.SEVERE, null, ex);
            }
     
                for (Map.Entry<String, Double> entry : map.entrySet())
                {
                    dataset.addValue(entry.getValue(), "Dólar", entry.getKey());
                    //System.out.println(entry.getKey() + "/" + entry.getValue());
                }
            
            
             try {
                url = new URL("http://michael.eti.br/java/EURO.csv");
                cotacoes.lerCotacao(url);
                                                          
               
            } catch (MalformedURLException ex) {
                Logger.getLogger(TelaInicial.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(TelaInicial.class.getName()).log(Level.SEVERE, null, ex);
            }
     
            for (Map.Entry<String, Double> entry : map.entrySet())
            {
                dataset.addValue(entry.getValue(), "Euro", entry.getKey());
                //System.out.println(entry.getKey() + "/" + entry.getValue());
            }

    

    //dataset.addValue(3.2, "Venda", "Outubro");
    //dataset.addValue(media(3.2,5.2,4.5), "Compra", "Outubro");
    
    //dataset.addValue(media(3.2,5.2,4.5), "Compra", "Setembro");
    //dataset.addValue(media(3.2,5.2,4.5), "Venda", "Setembro");
    return dataset; 
}

public static JFreeChart createBarChart(CategoryDataset dataset) {
JFreeChart chart = ChartFactory.createBarChart(
"Dólar", //Titulo
"Meses", // Eixo X
"Cotação Média", //Eixo Y
dataset, // Dados para o grafico
PlotOrientation.VERTICAL, //Orientacao do grafico
true, false, false); // exibir: legendas, tooltips, url
return chart;
}

public static void main( String[] args ) {
BarsGraphic chart = new BarsGraphic("Teste Cotação");
chart.pack();
chart.setVisible(true);
}
    

}