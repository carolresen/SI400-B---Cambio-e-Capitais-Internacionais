/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casacambio;


import com.opencsv.CSVReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Victória
 */
public class Cotacoes {
    Collection<Moeda>cotacao;
        
    //public List<Double> vCompra = new ArrayList<Double>();
    
    public LinkedHashMap<String,Double> vCompra = new LinkedHashMap<String,Double>();
    
    //Moeda moeda = new Moeda();
     
    public Cotacoes()
    {
        cotacao = new ArrayList();
    }
    
    public Collection<Moeda> lerCotacao(URL url) throws IOException
    {  
        Reader source = new InputStreamReader(url.openStream()); 
        CSVReader reader = new CSVReader(source, ';');
        String[] line;
        
        int i = 0;
        
        while ((line = reader.readNext()) != null) {
            Moeda moeda = new Moeda(line[0], line[1], Double.parseDouble(substituir(line[2])), Double.parseDouble(substituir(line[3])));
            cotacao.add(moeda);
            vCompra.put(line[0], Double.parseDouble(substituir(line[2])));
        }
        
        reader.close();
        source.close();
        return cotacao;
    }
    
    public Moeda buscarCotacao(String data)
    {
        Moeda valor = new Moeda();
        
            for (Moeda m : cotacao)
            { 
                if(m.getData().equals(data)){
                    valor = m;    
                }  
            }
    return valor;
    }    
       
        public String substituir(String a)
        {
            a=a.replace(",",".");
            return a;
        }    
        
        public String substituirBarra(String b)
        {
            b=b.replace("/","");
            return b;
        }   
        
        
        
        /*
        public void valoresCompra()
        {
            for (Moeda m : cotacao)
            { 
               vCompra.add(m.getCompra());
               System.out.println("valor" + m.getCompra());
            }
        }  
        */
        public LinkedHashMap <String,Double> getList(){
           return vCompra;
        }
      
}
